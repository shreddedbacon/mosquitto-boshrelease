<!--
.. title: Version 1.3.3 released
.. slug: version-1-3-3-released
.. date: 2014-08-01 22:55:42
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

# Broker

 * Fix incorrect handling of anonymous bridges on the local broker.

Binaries will follow shortly.
