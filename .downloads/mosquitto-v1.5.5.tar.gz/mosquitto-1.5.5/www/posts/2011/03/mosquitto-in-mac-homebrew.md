<!--
.. title: Mosquitto in Mac homebrew
.. slug: mosquitto-in-mac-homebrew
.. date: 2011-03-27 18:29:39
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Thanks to work done by Adam Rudd, mosquitto is now available in the Mac
[homebrew](https://brew.sh) package manager. Once you've installed homebrew
(see the link), you can install mosquitto with:

```
brew install mosquitto
```
