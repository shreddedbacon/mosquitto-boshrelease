<!--
.. title: Version 0.14.2 released
.. slug: version-0-14-2-released
.. date: 2011-11-28 21:20:46
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release:

 * Add uninstall target for libs.
 * Don't try to write packet whilst in a callback.
