<!--
.. title: Version 1.1.1 released
.. slug: version-1-1-1-released
.. date: 2013-01-16 23:57:00
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

# Broker

 * Fix crash on reload if using acl patterns.

# Client library

 * Fix static C++ functions not being exported on Windows. Fixes bug #1098256.

Binaries should be available shortly.
