<!--
.. title: Version 0.2 released
.. slug: version-0-2-released
.. date: 2009-12-04 10:49:06
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

Version 0.2 released - please see the [change log](/ChangeLog.txt).
