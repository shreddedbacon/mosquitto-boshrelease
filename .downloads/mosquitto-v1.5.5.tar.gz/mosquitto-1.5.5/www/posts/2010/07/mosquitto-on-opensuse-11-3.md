<!--
.. title: Mosquitto on openSUSE 11.3
.. slug: mosquitto-on-opensuse-11-3
.. date: 2010-07-12 12:39:25
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

The upcoming release of [openSUSE], version 11.3, includes extension support
for sqlite3 which means it now has everything required for mosquitto.

I've created packages for this new version of openSUSE and details can be found
on the [download page]. You just need to wait three days until the release of
11.3!

[openSUSE]: http://www.opensuse.org/
[download page]: /download
