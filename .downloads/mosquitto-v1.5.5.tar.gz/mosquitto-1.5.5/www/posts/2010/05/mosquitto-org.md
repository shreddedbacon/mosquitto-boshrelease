<!--
.. title: mosquitto.org
.. slug: mosquitto-org
.. date: 2010-05-31 17:48:08
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

I'm pleased to annouce that the mosquitto website is now available at
<http://mosquitto.org/> so please update your bookmarks! I'll be updating the
links here in a few days when the change has propagated.
