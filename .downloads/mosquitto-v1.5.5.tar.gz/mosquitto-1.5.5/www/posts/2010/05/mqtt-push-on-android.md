<!--
.. title: MQTT Push on Android
.. slug: mqtt-push-on-android
.. date: 2010-05-16 22:43:34
.. tags: Applications, Obsolete
.. category:
.. link:
.. description:
.. type: text
-->

If you want to use MQTT for push in Android apps, you'll probably want to head
over to Anton L's blog post [How to Implement Push Notifications for Android].
He has a sample Android app that uses the IBM Java library to implement push
notifications using MQTT, as well as a web page solution to demo pushing
notifications to your phone.

[How to Implement Push Notifications for Android]: http://tokudu.com/2010/how-to-implement-push-notifications-for-android/
