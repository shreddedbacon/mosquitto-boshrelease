<!--
.. title: Version 0.4.1 released
.. slug: version-0-4-1-released
.. date: 2010-01-12 22:10:13
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release:

 * Fix regex used for finding retained messages to send on new subscription.
