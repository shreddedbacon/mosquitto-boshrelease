<!--
.. title: Mailing list / irc
.. slug: mailing-list-irc
.. date: 2010-01-11 10:18:10
.. tags: Support
.. category:
.. link:
.. description:
.. type: text
-->

We've created some new support channels for mosquitto - a mailing list and an
irc channel. Although they are both intended for providing support for
mosquitto itself, general discussion of anything to do with mqtt is strongly
encouraged. We want to reduce the barrier to getting started and provide a
place where people can share their experiences.

The mailing list is at <http://launchpad.net/~mqtt-users>

The irc channel is #mqtt on the [freenode network]

[freenode network]: http://freenode.net/
